package edu.byu.cs;

import java.util.Date;

public class Student2 {
    private Date graduationDate;
}
