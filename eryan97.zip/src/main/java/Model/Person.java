package Model;

import java.util.Objects;

/**
 * A class that models the structure of the person table in the database
 */
public class Person {
    /**
     * A person id
     */
    private String personID;
    /**
     * the persons username
     */
    private String associatedUsername;
    /**
     * A first name
     */
    private String firstName;
    /**
     * A last name
     */
    private String lastName;
    /**
     * A string containing either 'm' or 'f' designating a persons gender
     */
    private String gender;
    /**
     * The person id of the father
     */
    private String fatherID;
    /**
     * The person id of the mother
     */
    private String motherID;
    /**
     * The person id of the spouse
     */
    private String spouseID;

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getAssociatedUsername() {
        return associatedUsername;
    }

    public void setAssociatedUsername(String associatedUsername) {
        this.associatedUsername = associatedUsername;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFatherID() {
        return fatherID;
    }

    public void setFatherID(String fatherID) {
        this.fatherID = fatherID;
    }

    public String getMotherID() {
        return motherID;
    }

    public void setMotherID(String motherID) {
        this.motherID = motherID;
    }

    public String getSpouseID() {
        return spouseID;
    }

    public void setSpouseID(String spouseID) {
        this.spouseID = spouseID;
    }

    /**
     * A constructor that creates a person object
     * @param personID
     * @param associatedUsername
     * @param firstName
     * @param lastName
     * @param gender
     * @param fatherID
     * @param motherID
     * @param spouseID
     */
    public Person(String personID, String associatedUsername, String firstName, String lastName, String gender, String fatherID, String motherID, String spouseID) {
        this.personID = personID;
        this.associatedUsername = associatedUsername;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.fatherID = fatherID;
        this.motherID = motherID;
        this.spouseID = spouseID;
    }

    public Person(User u){
        this.personID = u.getPersonID();
        this.associatedUsername = u.getUsername();
        this.firstName = u.getFirstName();
        this.lastName = u.getLastName();
        this.gender = u.getGender();
        this.fatherID = new String();
        this.motherID = new String();
        this.spouseID = new String();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return Objects.equals(gender,person.gender) && Objects.equals(personID, person.personID) && Objects.equals(associatedUsername, person.associatedUsername) && Objects.equals(firstName, person.firstName) && Objects.equals(lastName, person.lastName) && Objects.equals(fatherID, person.fatherID) && Objects.equals(motherID, person.motherID) && Objects.equals(spouseID, person.spouseID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(personID, associatedUsername, firstName, lastName, gender, fatherID, motherID, spouseID);
    }
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(personID);
        s.append('\n');
        s.append(associatedUsername);
        s.append('\n');
        s.append(firstName);
        s.append('\n');
        s.append(lastName);
        s.append('\n');
        s.append(gender);
        s.append('\n');
        s.append(fatherID);
        s.append('\n');
        s.append(motherID);
        s.append('\n');
        s.append(spouseID);
        s.append('\n');
        return s.toString();
    }
}