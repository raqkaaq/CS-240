package Data;

public class Names {
    private String name;

    public Names(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
