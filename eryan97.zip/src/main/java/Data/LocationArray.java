package Data;

public class LocationArray {
    private LocationData[] data;
    public LocationArray(){
        data = new LocationData[978];
    }

    public LocationData[] getData() {
        return data;
    }
}
